/*
 * Name: Siyuan Yang
 * Date: 03/01/2020
 * Version: (number, edited by) 
 * 	- 0.0.1 
 * 
 * Notes: Edits MenuController
 * 
 */
package org.team9.sportsDB;

import java.io.File;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Window;

public class MenuController {
	static FileChooser fc = new FileChooser();
	
    @FXML
    public void CloseApp(ActionEvent event) {
		Platform.exit();
		System.exit(0);
    }
    
    @FXML
    VBox vbMenu;
    
    @FXML
    public void handleSaveCliked(ActionEvent event) {
    	Window stage = vbMenu.getScene().getWindow();
    	fc.setTitle("Save as");
    	fc.setInitialFileName("mysave");
    	fc.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("text file", "*.txt"),
    			new FileChooser.ExtensionFilter("csv file", "*.csv"));
    	
    	try {
    		File file = fc.showSaveDialog(stage);
    		fc.setInitialDirectory(file.getParentFile());
    	} 
    	catch (Exception e) {
    		System.out.println("Error saving the file.");
    	}
    }
}
