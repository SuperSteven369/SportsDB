package org.team9.sportsDB;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RushYardsController {
	@FXML
	private TextField teamName;
	@FXML
	private Label myMessage1;
	@FXML
	private Label myMessage2;
	@FXML
	private Label myMessage3;
	@FXML
	private Label myMessage4;
	@FXML
	private Label myMessage5;
	@FXML
	private Label myMessage6;
	@FXML
	private Label myMessage7;
	@FXML
	private Label myMessage8;
	@FXML
	public Button btn;
	
	@FXML
	private void handleButtonAction(ActionEvent event) throws IOException{
		Stage stage = null;
		Parent root = null;
		if (event.getSource() == btn) {
			stage = (Stage) btn.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public ResultSet getHomeTeam(String teamName) {
		return App.connection.executeQuery(
			"SELECT DISTINCT \"Game\".\"homeTeamCode\", \"Game\".\"visitTeamCode\", \"TeamGameStatistics\".\"RushYard\", \"Game\".\"Year\""
			+ "FROM \"TeamGameStatistics\""
			+ "INNER JOIN \"Game\""
			+ "ON \"Game\".\"GameCode\" = \"TeamGameStatistics\".\"GameID\""
			+ "AND \"Game\".\"Year\" = \"TeamGameStatistics\".\"year\""
			+ "INNER JOIN \"Teams\""
			+ "ON \"Game\".\"visitTeamCode\" = \"Teams\".\"TeamCode\" OR \"Game\".\"homeTeamCode\" = \"Teams\".\"TeamCode\""
			+ "WHERE \"Teams\".\"Name\" = \'" + teamName + "\'"
			+ "ORDER BY \"TeamGameStatistics\".\"RushYard\" DESC;"
		);
	}
	
	public String getTeamName(int teamCode) {
		String query = String.format(
			"SELECT DISTINCT \"Teams\".\"Name\""
			+ "FROM \"Teams\""
			+ "WHERE \"Teams\".\"TeamCode\" = %d;", teamCode);
		ResultSet teamName = App.connection.executeQuery(query);
		try {
			if (teamName.next()) {
				return teamName.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "";
	}
	
	public void getHomeTeamYard(ActionEvent event) {
		ResultSet result = getHomeTeam(teamName.getText());
		try {
			if (result.next()) {
				int homeTeamCode = Integer.parseInt(result.getString(1));
				int visitTeamCode = Integer.parseInt(result.getString(2));
				String homeTeamName = getTeamName(homeTeamCode);
				String visitTeamName = getTeamName(visitTeamCode);
				String m1 = homeTeamName;
				String m2 = visitTeamName;
				String m3 = result.getString(3);
				String m4 = result.getString(4);
				myMessage1.setText(m1);
				myMessage2.setText(m2);
				myMessage3.setText(m3);
				myMessage4.setText(m4);
		    }
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}	
}
