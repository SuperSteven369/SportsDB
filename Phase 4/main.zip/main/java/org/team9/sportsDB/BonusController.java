package org.team9.sportsDB;
import java.io.IOException;
//import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Locale.Category;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

//import com.sun.tools.javac.util.Options;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;
//import sun.tools.tree.ReturnStatement;

public class BonusController {
	ObservableList<String> Options = FXCollections.observableArrayList("Most Players", "Most Recievers", "Most Punters");

	@FXML
	private Label townResult;
	@FXML
	private Label Label1;
	@FXML
	private Label Label2;
	@FXML
	private ChoiceBox<String> choices;
	@FXML
	public Button btnBack;
	
	@FXML
	private void handleButtonAction(ActionEvent event) throws IOException{
		Stage stage = null;
		Parent root = null;
		if (event.getSource() == btnBack) {
			stage = (Stage) btnBack.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	@FXML
	private void initialize() {
		choices.setItems(Options);
		
		
	}
	
	public ResultSet Players() {
		return App.connection.executeQuery("SELECT DISTINCT \"Player\".\"PlayerCode\", \"Player\".\"LastName\", \"Player\".\"FirstName\", \"Player\".\"HomeTown\"\n" + 
				"FROM \"Player\"\n" + 
				"WHERE \"Player\".\"HomeTown\" IS NOT NULL;");
	}
	
	public ResultSet Punters() {
		return App.connection.executeQuery("SELECT DISTINCT \"Player\".\"PlayerCode\", \"Player\".\"LastName\", \"Player\".\"FirstName\", \"Player\".\"HomeTown\", \"Player\".\"Position\"\n" + 
				"FROM \"Player\"\n" + 
				"WHERE \"Player\".\"HomeTown\" IS NOT NULL AND \"Player\".\"Position\" = 'P';");
	}
	
	public ResultSet Recievers() {
		return App.connection.executeQuery("SELECT DISTINCT \"Player\".\"PlayerCode\", \"Player\".\"LastName\", \"Player\".\"FirstName\", \"Player\".\"HomeTown\", \"Player\".\"Position\"\n" + 
				"FROM \"Player\"\n" + 
				"WHERE \"Player\".\"HomeTown\" IS NOT NULL AND \"Player\".\"Position\" = 'WR';");
	}
	
	public String mostOften(String[] arr) // USED FROM GREEKSFORGREEKS
	{
		// Create HashMap to store word and it's frequency 
        HashMap<String, Integer> hs = new HashMap<String, Integer>(); 
  
        // Iterate through array of words 
        for (int i = 0; i < arr.length; i++) { 
            // If word already exist in HashMap then increase it's count by 1 
            if (hs.containsKey(arr[i])) { 
                hs.put(arr[i], hs.get(arr[i]) + 1); 
            } 
            // Otherwise add word to HashMap 
            else { 
                hs.put(arr[i], 1); 
            } 
        } 
  
        // Create set to iterate over HashMap 
        Set<Map.Entry<String, Integer> > set = hs.entrySet(); 
        String key = ""; 
        int value = 0; 
  
        for (Map.Entry<String, Integer> me : set) { 
            // Check for word having highest frequency 
            if (me.getValue() > value) { 
                value = me.getValue(); 
                key = me.getKey(); 
            } 
        } 
  
        // Return word having highest frequency 
        return key; 
	}
	
	
	public void Points(ActionEvent event) {
		String categ = choices.getSelectionModel().getSelectedItem();
		String ans = "";
		ResultSet result;
		if(categ == "Most Players")
		{
			
			result = Players();
			Vector<String> alltowns = new Vector<>();
			try {
				while (result.next()) {
					String town = result.getString(4);
					alltowns.add(town);
			    }
			} catch (SQLException e) {
				e.printStackTrace();
			}
			String[] array = alltowns.toArray(new String[alltowns.size()]); 
			
		    ans = mostOften(array);
		    townResult.setText(ans);
			
		}
		else if(categ == "Most Recievers")
		{
			result = Recievers();
			Vector<String> alltowns = new Vector<>();
			try {
				while (result.next()) {
					String town = result.getString(4);
					alltowns.add(town);
			    }
			} catch (SQLException e) {
				e.printStackTrace();
			}
			String[] array = alltowns.toArray(new String[alltowns.size()]); 
			
		    ans = mostOften(array);
		    townResult.setText(ans);
		}
		else if(categ == "Most Punters")
		{
			result = Punters();
			Vector<String> alltowns = new Vector<>();
			try {
				while (result.next()) {
					String town = result.getString(4);
					alltowns.add(town);
			    }
			} catch (SQLException e) {
				e.printStackTrace();
			}
			String[] array = alltowns.toArray(new String[alltowns.size()]); 
			
		    ans = mostOften(array);
		    townResult.setText(ans);
		}
		
		
	}	
}
