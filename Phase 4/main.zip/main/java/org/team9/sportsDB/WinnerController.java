package org.team9.sportsDB;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javafx.collections.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;

public class WinnerController {
	ObservableList<String> typeList = FXCollections.observableArrayList("Basic", "Advanced");
	
	@FXML
	public TextField team1;
	
	@FXML
	public TextField team2;
	
	@FXML
	public ChoiceBox<String> type;
	
	@FXML
	public Button search;
	
	@FXML 
	public Label results;
	
	@FXML
	public Button btn;
	
	@FXML
	private void handleButtonAction(ActionEvent event) throws IOException{
		Stage stage = null;
		Parent root = null;
		if (event.getSource() == btn) {
			stage = (Stage) btn.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public ResultSet basic(String teamA, String teamB) throws SQLException{
		String team1name = "";
		String team2name = "";
		
		ResultSet team1results =  App.connection.executeQuery(
			"SELECT DISTINCT \"Teams\".\"TeamCode\" " +
			"FROM \"Teams\" " +
			"WHERE \"Teams\".\"Name\" = '" +
			teamA.strip() +
			"';"
		);
		
		ResultSet team2results = App.connection.executeQuery(
			"SELECT DISTINCT \"Teams\".\"TeamCode\" " +
			"FROM \"Teams\" " +
			"WHERE \"Teams\".\"Name\" = '" +
			teamB.strip() +
			"';"
		);
		
		if (team1results.next()) {
			team1name = team1results.getObject("TeamCode").toString();
		}
		if (team2results.next()) {
			team2name = team2results.getObject("TeamCode").toString();
		}

		ResultSet gameResults = App.connection.executeQuery(
			"SELECT v.\"year\" " +
			"FROM \"TeamGameStatistics\" h, \"TeamGameStatistics\" v " +
			"WHERE h.\"TeamCode\" = " +
			team1name + 
			" AND v.\"TeamCode\" = " +
			team2name +  
			" AND h.\"GameID\" = v.\"GameID\" AND h.\"Points\" > v.\"Points\";"
		);
		
		return gameResults;
	}
	
	public int advanced(String teamA, String teamB) throws SQLException{
		String team1name = "";
		String team2name = "";
		
		ResultSet team1results =  App.connection.executeQuery(
			"SELECT DISTINCT \"Teams\".\"TeamCode\" " +
			"FROM \"Teams\" " +
			"WHERE \"Teams\".\"Name\" = '" +
			teamA.strip() +
			"';"
		);
		
		ResultSet team2results = App.connection.executeQuery(
			"SELECT DISTINCT \"Teams\".\"TeamCode\" " +
			"FROM \"Teams\" " +
			"WHERE \"Teams\".\"Name\" = '" +
			teamB.strip() +
			"';"
		);
		
		
		if (team1results.next()) {
			team1name = team1results.getObject("TeamCode").toString();
		}else {
			return 0;
		}
		if (team2results.next()) {
			team2name = team2results.getObject("TeamCode").toString();
		} else {
			return 0;
		}
		
	
		
		ResultSet gameResults1 = App.connection.executeQuery(
			"SELECT DISTINCT f.\"TeamCode\" FROM \"TeamGameStatistics\" h, \"TeamGameStatistics\" f WHERE h.\"TeamCode\" = " + 
			team1name + 
			" AND h.\"GameID\" = f.\"GameID\" AND h.\"Points\" > f.\"Points\" INTERSECT SELECT s.\"TeamCode\" " +
			"FROM \"TeamGameStatistics\" v, \"TeamGameStatistics\" s WHERE v.\"GameID\" = s.\"GameID\" AND v.\"Points\" < s.\"Points\";"
		);
		ResultSet gameResults2 = App.connection.executeQuery(
			"SELECT DISTINCT two.\"TeamCode\" FROM \"TeamGameStatistics\" one, \"TeamGameStatistics\" two " + 
			"WHERE one.\"GameID\" = two.\"GameID\" AND one.\"Points\" > two.\"Points\" INTERSECT SELECT " + 
			"three.\"TeamCode\" FROM \"TeamGameStatistics\" three, \"TeamGameStatistics\" v " + 
			"WHERE v.\"TeamCode\" = " +
			team2name +  
			" AND three.\"GameID\" = v.\"GameID\" AND v.\"Points\" < three.\"Points\";"
		);
		
		Vector<String> possibleOnes = new Vector<String>();
		Vector<String> possibleTwos = new Vector<String>();
		
		while(gameResults1.next()) {
			possibleOnes.add(gameResults1.getObject("TeamCode").toString());
		}
		while(gameResults2.next()) {
			possibleTwos.add(gameResults2.getObject("TeamCode").toString());
		}
		
		if(possibleOnes.size() == 0 || possibleTwos.size() == 0) {
			return 0;
		}
	
		
		String firstTeam = "";
		String secondTeam = "";
		String middleYear = "";
		
		boolean exitState = false;
		for(int i = 0; i < possibleOnes.size(); i++) {
			if(exitState) {
				break;
			}
			for(int j = 0; j < possibleTwos.size(); j++) {
				if(exitState) {
					break;
				}
				ResultSet middleGameResults = App.connection.executeQuery(
					"SELECT v.\"year\" " +
					"FROM \"TeamGameStatistics\" h, \"TeamGameStatistics\" v " +
					"WHERE h.\"TeamCode\" = " +
					possibleOnes.get(i) + 
					" AND v.\"TeamCode\" = " +
					possibleTwos.get(j) +  
					" AND h.\"GameID\" = v.\"GameID\" AND h.\"Points\" > v.\"Points\";"
				);
				if(middleGameResults.next()) {
					firstTeam = possibleOnes.get(i);
					secondTeam = possibleTwos.get(j);
					middleYear = middleGameResults.getObject("year").toString();
					exitState = true;
				}
			}
		}

		
		if(firstTeam.equals("") || secondTeam.equals("")) {
			return 0;
		}
		
		ResultSet firstGameResults = App.connection.executeQuery(
			"SELECT v.\"year\" " +
			"FROM \"TeamGameStatistics\" h, \"TeamGameStatistics\" v " +
			"WHERE h.\"TeamCode\" = " +
			team1name + 
			" AND v.\"TeamCode\" = " +
			firstTeam +  
			" AND h.\"GameID\" = v.\"GameID\" AND h.\"Points\" > v.\"Points\";"
		);
		
		ResultSet lastGameResults = App.connection.executeQuery(
			"SELECT v.\"year\" " +
			"FROM \"TeamGameStatistics\" h, \"TeamGameStatistics\" v " +
			"WHERE h.\"TeamCode\" = " +
			secondTeam + 
			" AND v.\"TeamCode\" = " +
			team2name +  
			" AND h.\"GameID\" = v.\"GameID\" AND h.\"Points\" > v.\"Points\";"
		);
		
		String firstYear = "";
		String lastYear = "";
		
		if(firstGameResults.next()) {
			firstYear = firstGameResults.getObject("year").toString();
		}else {
			return 0;
		}
		
		if(lastGameResults.next()) {
			lastYear = lastGameResults.getObject("year").toString();
		}else {
			return 0;
		}
		
		String firstTeamName = "";
		String secondTeamName = "";
		
		ResultSet firstTeamResults = App.connection.executeQuery(
			"SELECT DISTINCT \"Teams\".\"Name\" FROM \"Teams\" WHERE \"Teams\".\"TeamCode\" = " + 
			firstTeam +
			";"
		);
		
		ResultSet secondTeamResults = App.connection.executeQuery(
			"SELECT DISTINCT \"Teams\".\"Name\" FROM \"Teams\" WHERE \"Teams\".\"TeamCode\" = " + 
			secondTeam +
			";"
		);
		
		if(firstTeamResults.next()) {
			firstTeamName = firstTeamResults.getObject("Name").toString();
		} else {
			return 0;
		}
		
		if(secondTeamResults.next()) {
			secondTeamName = secondTeamResults.getObject("Name").toString();
		} else {
			return 0;
		}
		
		results.setText(
			teamA+ 
			" beat " + 
			firstTeamName + 
			" " + 
			firstYear + 
			", \n" + 
			firstTeamName+ 
			" beat " + 
			secondTeamName + 
			" " + 
			middleYear + 
			", and \n" + 
			secondTeamName + 
			" beat " + 
			teamB + 
			" " + 
			lastYear + 
			"."
		);
		
		return 1;
	}
	
	@FXML
	void display(ActionEvent event) throws SQLException {
		results.setVisible(true);
		String team1name = team1.getText();
		String team2name = team2.getText();
		
		if (type.getValue().equals("Advanced")) {
			results.setText("Loading...");
			int advancedResults = advanced(team1name, team2name);
			if(advancedResults == 0) {
				results.setText("There were no statistics available for these inputs.");
			}
		} else {
			results.setText("Loading...");
			ResultSet basicResults = basic(team1name, team2name);
			String basicYear = "";
			if(basicResults.next()) {
				basicYear = basicResults.getObject("year").toString();
				results.setText(
					team1name + 
					" beat " + 
					team2name + 
					" " + 
					basicYear + 
					"."
				);
			} else {
				results.setText(
					"There are no years where " + 
					team1name + 
					" beats " + 
					team2name + 
					"."
				);
			}
		}
	}
	
	
	public void initialize() { 
		type.setItems(typeList);
		type.setValue(typeList.get(0));
		results.setVisible(false);
	}
	
}