/*
 * Name: Team9
 * Date: 02/29/2020
 * Version: (number, edited by) 
 * 	- 0.0.1 
 * 
 * Notes: 
 * 
 */
package org.team9.sportsDB;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;

import org.team9.dbConnection.DBConnection;

/**
 * JavaFX App
 */
public class App extends Application {

    private static Scene scene;
    public static DBConnection connection;

    @Override
    public void start(Stage stage) throws IOException {
    	try {
    		connection = new DBConnection();
            scene = new Scene(loadFXML("Dashboard"));
            stage.setScene(scene);
           
            stage.setOnCloseRequest(e -> {
            	System.out.println("Exiting the program, and closing sql connection");
            	connection.closeConnection();
            	Platform.exit();
            	
            });
            stage.show();
        }
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    }
    	

    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
        
    }

}