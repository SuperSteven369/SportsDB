/*
 * Name: Sacheth Swaminathan
 * Date: 02/29/2020
 * Version: (number, edited by) 
 * 	- 0.0.1 Sacheth 
 * 
 * Notes: Manages the columns for the database 
 * 
 */
package org.team9.sportsDB;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;



import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

public class ColumnsController implements Initializable {
	@FXML
    private TableView<String> mainTable = new TableView<String>();
	
	private DashboardController dashController;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		System.out.println("init columns ");	
		mainTable.setPlaceholder(new Label("My table is empty message"));
		
		}
		
//	
//	/**
//	 * Returns a table from a query
//	 * @param name the table name
//	 * @return the ResultSet from the query
//	 */
//	public static ResultSet getTable(String name) {
//		return App.connection.executeQuery("SELECT * FROM \"" + name.strip() +"\";");
//		
//	}

	
	
	public void updateTable(String name) {
		//Make new table, also reseting the tableview
		System.out.println("Update table called");
		mainTable.getItems().clear();
		mainTable.getColumns().clear();

		
		String query = "SELECT column_name, data_type FROM information_schema.columns\r\n" + 
				"WHERE table_schema = 'public' \r\n" + 
				"AND table_name  = N\'" + name + "\';";
		
			
			ResultSet columnNamesFromTable = App.connection.executeQuery(query);
//			ObservableList<String> dataType = FXCollections.observableArrayList();
			try {
				ObservableList<TableColumn<String, String>> co = FXCollections.observableArrayList();
				while(columnNamesFromTable.next()) {// Adds the column names to the colNames list
					//Adding columns to table
					String col = columnNamesFromTable.getString("column_name");
					TableColumn<String, String> column = new TableColumn<String, String>(col);
					column.setCellValueFactory(param -> new ReadOnlyStringWrapper(param.getValue()));
					mainTable.getColumns().add(column);
					System.out.println("Size of columns " + mainTable.getColumns().size());

				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		
		
		
		
		// The values in the table
		ResultSet results = App.connection.executeQuery("SELECT * FROM \"" + name.strip() +"\" LIMIT 10;"); 
		try {
			while(results.next()) {
				ObservableList<String> colNames = FXCollections.observableArrayList();
				for(int i = 1; i <= results.getMetaData().getColumnCount(); i++) {
					colNames.add(results.getString(i));
					
					
					
					System.out.print(results.getString(i) + " ");
				}
				System.out.println();
				
				mainTable.getItems().addAll(colNames);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setParentController(DashboardController dashboardController) {
		// TODO Auto-generated method stub
		this.dashController = dashboardController;
	}
	
	
	

	
}