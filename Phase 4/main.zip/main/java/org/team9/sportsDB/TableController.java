/*
 * Name: Meghana Pothugunta
 * Date: 02/29/2020
 * Version: (number, edited by) 
 * 	- 0.0.1 
 * 
 * Notes: 
 * 
 */

package org.team9.sportsDB;


import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.team9.dbConnection.DBConnection;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;

public class TableController implements Initializable {
	
	private DashboardController dashboardController;
	
    @FXML
    public ListView<String> listViewTables = new ListView<String>();
    
    public static String selectedTable; // Update this variable when an onClick action happens
    
    
    public void setParentController(DashboardController dashController) {
    	this.dashboardController = dashController;
		
    }


    public void initialize(URL location, ResourceBundle resources) {
		
    	
		
		// calling on all tables from database
		ResultSet rSet = App.connection.executeQuery("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE table_type = 'BASE TABLE' AND table_schema = 'public';");
		
		try
		{
			// Go through resultset and add the tables to the listview
			while (rSet.next()) {
				listViewTables.getItems().add(rSet.getString("TABLE_NAME"));
			  }
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		if (!listViewTables.getItems().isEmpty()) {
			listViewTables.getSelectionModel().select(0);
			selectedTable = listViewTables.getSelectionModel().getSelectedItem();
//			dashboardController.updateTable(selectedTable);
			
		}
		
//		listViewTables.setOnMouseClicked(new EventHandler<MouseEvent>(){
//	          @Override
//	          public void handle(MouseEvent arg0) {
//	        	  dashController.updateSelectedTable(selectedTable);
//	              
//	             
//	          }
//	    });
		
		
	}

//    @FXML 
//    public void selectTable(ActionEvent e) {
//    	selectedTable = listViewTables.getSelectionModel().getSelectedItem();
////    	dashboardController.updateTable(selectedTable);
//    }

    
    

}
