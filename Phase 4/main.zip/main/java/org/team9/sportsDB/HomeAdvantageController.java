package org.team9.sportsDB;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.stage.Stage;
import javafx.scene.control.TableView;
import javafx.util.Callback;

public class HomeAdvantageController implements Initializable {

@FXML
private Button generateButton = new Button();

@FXML
private ChoiceBox<String> selectConference = new ChoiceBox<String>();

@FXML
private ChoiceBox<String> selectTime = new ChoiceBox<String>();

@FXML
TableView tableView = new TableView();

@FXML
private Button backButton;


@FXML
void backButtonAction(ActionEvent event) throws IOException {
	Stage stage = null;
	Parent root = null;
	if (event.getSource() == backButton) {
		stage = (Stage) backButton.getScene().getWindow();
		root = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
	}
	Scene scene = new Scene(root);
	stage.setScene(scene);
	stage.show();
}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		
		selectTime.getItems().add("Current");
		selectTime.getItems().add("Last 3 Years");
		selectTime.getItems().add("All time");
		selectTime.setValue("Current");
		generateConferences();
		generateButton.setOnAction(new EventHandler<ActionEvent>() {
		    @Override public void handle(ActionEvent e) {
		    	generateTable();
		    }
		});
		
	}
	
	
	// TODO: Generate the conferences 
	public void generateConferences() {
		ResultSet rSet = App.connection.executeQuery("SELECT \"ConferenceName\" FROM \"Conference\"");
		ObservableList<String> c = FXCollections.observableArrayList();
		try {
			while(rSet.next()) {
				c.add(rSet.getString("ConferenceName"));
			}
			selectConference.setItems(c);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void generateTable() {
		System.out.println("Update table called");
		tableView.getItems().clear();
		tableView.getColumns().clear();
		if((String)selectConference.getValue() == null) {
			System.out.println("No conference selected");
		}else {
			String query = "SELECT team1.\"Name\", \r\n" + 
					"	\r\n" + 
					"	(CASE \r\n" + 
					"		  WHEN (cast(median(score1.\"Points\" - score2.\"Points\") as decimal(4,2)))   <= -20 THEN 0\r\n" + 
					"		  WHEN (cast(median(score1.\"Points\" - score2.\"Points\") as decimal(4,2)))   <= -15 THEN 10\r\n" + 
					"		  WHEN (cast(median(score1.\"Points\" - score2.\"Points\") as decimal(4,2)))   <= -10 THEN 20\r\n" + 
					"		  WHEN (cast(median(score1.\"Points\" - score2.\"Points\") as decimal(4,2)))   <= -5 THEN 30\r\n" + 
					"		  WHEN (cast(median(score1.\"Points\" - score2.\"Points\") as decimal(4,2)))   <= 0 THEN 40\r\n" + 
					"		  WHEN (cast(median(score1.\"Points\" - score2.\"Points\") as decimal(4,2)))   <= 5 THEN 50\r\n" + 
					"		  WHEN (cast(median(score1.\"Points\" - score2.\"Points\") as decimal(4,2)))   <= 10 THEN 60\r\n" + 
					"		  WHEN (cast(median(score1.\"Points\" - score2.\"Points\") as decimal(4,2)))   <= 15 THEN 70\r\n" + 
					"		  WHEN (cast(median(score1.\"Points\" - score2.\"Points\") as decimal(4,2)))   <= 20 THEN 80\r\n" + 
					"		  WHEN (cast(median(score1.\"Points\" - score2.\"Points\") as decimal(4,2)))   <= 25 THEN 90\r\n" + 
					"		  ELSE 100\r\n" + 
					"	END ) as \"Rank(0-100)\"\r\n" + 
					"	\r\n" + 
					"	FROM \"Game\" \r\n" + 
					"	\r\n" + 
					"	INNER JOIN \"Teams\" as team1\r\n" + 
					"	ON \"Game\".\"homeTeamCode\" = team1.\"TeamCode\"\r\n" + 
					"	INNER JOIN \"Teams\" as team2\r\n" + 
					"	ON \"Game\".\"visitTeamCode\" = team2.\"TeamCode\"\r\n" + 
					"	\r\n" + 
					"	left JOIN \"TeamGameStatistics\" as score1\r\n" + 
					"	ON \"Game\".\"GameCode\" = score1.\"GameID\" \r\n" + 
					"	AND score1.\"TeamCode\" = team1.\"TeamCode\"\r\n" + 
					"	\r\n" + 
					"	left JOIN \"TeamGameStatistics\" as score2\r\n" + 
					"	ON \"Game\".\"GameCode\" = score2.\"GameID\" \r\n" + 
					"	AND score2.\"TeamCode\" = team2.\"TeamCode\"\r\n" + 
					"	\r\n" + 
					"	INNER JOIN \"Conference\" \r\n" + 
					"	ON team1.\"ConferenceCode\" = \"Conference\".\"ConferenceCode\"\r\n" + 
					"	WHERE \"Conference\".\"ConferenceName\" = \'" + selectConference.getValue().strip() + "\'\r\n"; 
			
			switch(selectTime.getSelectionModel().getSelectedIndex()) {
				case 0: 
				{
					query += "AND \"Game\".\"Year\" = 2013 AND team1.\"Year\" = 2013 AND team2.\"Year\" = 2013\r\n";
							
				}
				break;
				case 1:
				{
					query += "AND \"Game\".\"Year\" >= 2010 AND team1.\"Year\" >= 2010 AND team2.\"Year\" = 2013\r\n";
					break;
				}
				default: 
					break;
						
			}
			query += "	GROUP BY team1.\"Name\"\r\n" + 
					"	ORDER BY team1.\"Name\";\r\n";
			ResultSet results = App.connection.executeQuery(query);
			ObservableList data = FXCollections.observableArrayList();
			try {
			 /**********************************
	         * TABLE COLUMN ADDED DYNAMICALLY *
	         **********************************/
	        for(int i=0 ; i<results.getMetaData().getColumnCount(); i++){
	            //We are using non property style for making dynamic table
	        	if(i == results.getMetaData().getColumnCount())break;
	            final int j = i;                
	            TableColumn col = new TableColumn(results.getMetaData().getColumnName(i+1));
	            col.setCellValueFactory(new Callback<CellDataFeatures<ObservableList,String>,ObservableValue<String>>(){                    
	                public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {                                                                                              
	                    return new SimpleStringProperty(param.getValue().get(j).toString());                        
	                }                    
	            });

	            tableView.getColumns().addAll(col); 
	            System.out.println("Column ["+i+"] ");
	        }

	        /********************************
	         * Data added to ObservableList *
	         ********************************/
	        while(results.next()){
	            //Iterate Row
	            ObservableList<String> row = FXCollections.observableArrayList();
	            for(int i=1 ; i<=results.getMetaData().getColumnCount(); i++){
	                //Iterate Column
	                row.add(results.getString(i));
	            }
	            System.out.println("Row [1] added "+row );
	            data.add(row);

	        }

	        //FINALLY ADDED TO TableView
	        tableView.setItems(data);
	      }catch(Exception e){
	          e.printStackTrace();
	          System.out.println("Error on Building Data");             
	      }
		}
	}
	
	
	

}
