/*
 * Name: 
 * Date: 02/29/2020
 * Version: (number, edited by) 
 * 	- 0.0.1 
 * 
 * Notes: 
 * 
 */
package org.team9.sportsDB;


import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;


import javafx.collections.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class StatsController{
	// lists that contain options for users
	ObservableList<String> statsList = FXCollections.observableArrayList("Item Count");
	ObservableList<String> extendedStatsList = FXCollections.observableArrayList("Item Count", "Min Value", "Max Value");
	ObservableList<String> gameColList = FXCollections.observableArrayList("Attendance", "Duration");
	ObservableList<String> playerColList = FXCollections.observableArrayList("RushAtt", "PassAtt");
	
	@FXML
	public ChoiceBox<String> statsbox;
	
	@FXML
	public ChoiceBox<String> colsbox;
	
	@FXML
	public Button statsbutton;
	
	@FXML
	public Label statslabel;
	
	@FXML
	public Label functionlabel;
	
	@FXML
	public Label collabel;
	
	@FXML
	public Button loadoptionsbutton;
	
	@FXML
	public Button btn1;
	
	@FXML
	public Button btn2;
	
	@FXML
	public Button btn3;
	
	@FXML
	public Button btn4;
	
	@FXML
	public Button btnBonus;
	
	@FXML
	private void handleButtonAction1(ActionEvent event) throws IOException{
		Stage stage = null;
		Parent root = null;
		if (event.getSource() == btn1) {
			stage = (Stage) btn1.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("Winner.fxml"));
		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	@FXML
	private void handleButtonAction2(ActionEvent event) throws IOException{
		Stage stage = null;
		Parent root = null;
		if (event.getSource() == btn2) {
			stage = (Stage) btn2.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("HomeAdvantage.fxml"));
		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	@FXML
	private void handleButtonAction3(ActionEvent event) throws IOException{
		Stage stage = null;
		Parent root = null;
		if (event.getSource() == btn3) {
			stage = (Stage) btn3.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("RushYards.fxml"));
		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	
	@FXML
	private void handleButtonAction4(ActionEvent event) throws IOException{
		Stage stage = null;
		Parent root = null;
		if (event.getSource() == btn4) {
			stage = (Stage) btn4.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("PointsGraph.fxml"));
		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	@FXML
	private void handleButtonActionBonus(ActionEvent event) throws IOException{
		Stage stage = null;
		Parent root = null;
		if (event.getSource() == btnBonus) {
			stage = (Stage) btnBonus.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("Bonus.fxml"));
		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	// function to get row count
	public ResultSet getCount(String table) {
		return App.connection.executeQuery("SELECT COUNT(*) FROM \"" + table.strip() + "\";");
	}
	
	// function to get max value
	public ResultSet getMax(String table, String col) {
		return App.connection.executeQuery(
			"SELECT MAX(\"" + 
			col.strip() + 
			"\") " + 
			"FROM \"" +
			TableController.selectedTable.strip() + 
			"\";"
		);
	}
	
	// function to get min value
	public ResultSet getMin(String table, String col) {
		return App.connection.executeQuery(
			"SELECT MIN(\"" + 
			col.strip() + 
			"\") " + 
			"FROM \"" +
			TableController.selectedTable.strip() + 
			"\";"
		);
	}
	
	
    @FXML
    void display(ActionEvent event) throws SQLException {
    	if (statsbox.getValue() != null) {
        	// call query to get information
        	if (statsbox.getValue().equals("Item Count")) {
        		ResultSet tablecount = getCount(TableController.selectedTable);
        		if (tablecount.next()) {
        			statslabel.setText("There are " + tablecount.getObject("count").toString() + " rows in the table \"" + TableController.selectedTable + "\"." );
        		}
        	} else if (statsbox.getValue().equals("Min Value")) {
        		ResultSet tablemin = getMin(TableController.selectedTable, colsbox.getValue());
        		if (tablemin.next()) {
        			String temp = "";
            		if (tablemin.getObject("min") == null) {
            			temp = "0";		
            		} else {
            			temp = tablemin.getObject("min").toString();
            		}
        			statslabel.setText("The min value for the table \"" + TableController.selectedTable + "\" is "  + temp +  "." );
        		}
        	} else if (statsbox.getValue().equals("Max Value")) {
        		ResultSet tablemax = getMax(TableController.selectedTable, colsbox.getValue());
        		if (tablemax.next()) {
        			String temp = "";
            		if (tablemax.getObject("max") == null) {
            			temp = "0";		
            		} else {
            			temp = tablemax.getObject("max").toString();
            		}
        			statslabel.setText("The max value for the table \"" + TableController.selectedTable + "\" is " + temp +  "." );
        		}
        	}
    	}
    	
    	initialize();
    }
	
    @FXML
    void displayOptions(ActionEvent event) {
		if (TableController.selectedTable != null) {
	    	statsbox.setVisible(true);
	    	loadoptionsbutton.setVisible(false);
	    	statsbutton.setVisible(true);
	    	functionlabel.setVisible(true);
	    	statslabel.setText("Fill in the option(s) above for the table \"" + TableController.selectedTable + "\" and click load..");
	    	
			// first choice box for function
			if (TableController.selectedTable.strip().equals("GameStatistics") || TableController.selectedTable.strip().equals("PlayerGameStatistics")) {
				statsbox.setItems(extendedStatsList);
				statsbox.setValue(extendedStatsList.get(0));
				colsbox.setVisible(true);
				collabel.setVisible(true);
			} else {
				statsbox.setItems(statsList);
				statsbox.setValue(statsList.get(0));
				colsbox.setVisible(false);
				collabel.setVisible(false);
			}
			
			// second choice for 
			if (TableController.selectedTable.strip().equals("GameStatistics")) {
				colsbox.setItems(gameColList);
				colsbox.setValue(gameColList.get(0));
			} else if (TableController.selectedTable.strip().equals("PlayerGameStatistics")) {
				colsbox.setItems(playerColList);
				colsbox.setValue(playerColList.get(0));
			}
			
	    } else {
	    	statslabel.setText("Please select a table and click new search again.");
	    	initialize();
	    }
    }
    
	public void initialize() { 
		statsbox.setVisible(false);
    	colsbox.setVisible(false);
    	loadoptionsbutton.setVisible(true);
    	statsbutton.setVisible(false);
    	functionlabel.setVisible(false);
    	collabel.setVisible(false);
	}
	
	
}

