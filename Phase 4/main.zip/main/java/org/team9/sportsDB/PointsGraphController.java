package org.team9.sportsDB;
import java.io.IOException;
//import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale.Category;

//import com.sun.tools.javac.util.Options;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
//import sun.tools.tree.ReturnStatement;

public class PointsGraphController {
	ObservableList<String> Options = FXCollections.observableArrayList("All", "Home Games", "Away Games");
	CategoryAxis xAxis = new CategoryAxis();
//	xAxis.setLabel("Year");
	
	NumberAxis yAxis = new NumberAxis();
//	yAxis.setLabel("Points");
	@FXML
	private TextField teamName;
	@FXML
	private Label Label1;
	@FXML
	private Label Label2;
	@FXML
	private ChoiceBox<String> choices;
	@FXML
	public Button btnBack;
	@FXML
	private LineChart<String, Number> lineChart = new LineChart<String, Number>(xAxis,yAxis);
	
	@FXML
	private void handleButtonAction(ActionEvent event) throws IOException{
		Stage stage = null;
		Parent root = null;
		if (event.getSource() == btnBack) {
			stage = (Stage) btnBack.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	@FXML
	private void initialize() {
		choices.setValue("All");
//		choices.getItems().add("Home Game");
//		choices.getItems().add("Away Game");
		choices.setItems(Options);
		
		
	}
	
	public ResultSet getAllInfo(String teamName) {
		return App.connection.executeQuery("SELECT DISTINCT \"TeamGameStatistics\".\"Points\", \"TeamGameStatistics\".\"GameID\", \"TeamGameStatistics\".\"year\", \"Game\".\"Date\"\n" + 
				"FROM \"TeamGameStatistics\" \n" + 
				"INNER JOIN \"Game\"\n" + 
				"ON \"TeamGameStatistics\".\"GameID\" = \"Game\".\"GameCode\"\n" + 
				"INNER JOIN \"Teams\"\n" + 
				"ON \"TeamGameStatistics\".\"TeamCode\" = \"Teams\".\"TeamCode\" \n" + 
				"WHERE \"Teams\".\"Name\" = \'" + teamName + "\'" + 
				"ORDER BY \"Game\".\"Date\";");
	}
	
	public ResultSet getHomeInfo(String teamName) {
		return App.connection.executeQuery("SELECT DISTINCT \"TeamGameStatistics\".\"Points\", \"TeamGameStatistics\".\"GameID\", \"TeamGameStatistics\".\"year\", \"Game\".\"Date\"\n" + 
				"FROM \"TeamGameStatistics\" \n" + 
				"INNER JOIN \"Game\"\n" + 
				"ON \"TeamGameStatistics\".\"GameID\" = \"Game\".\"GameCode\" AND \"TeamGameStatistics\".\"TeamCode\" = \"Game\".\"homeTeamCode\"\n" + 
				"INNER JOIN \"Teams\"\n" + 
				"ON \"TeamGameStatistics\".\"TeamCode\" = \"Teams\".\"TeamCode\" \n" + 
				"WHERE \"Teams\".\"Name\" = \'" + teamName + "\'" + 
				"ORDER BY \"Game\".\"Date\";");
	}
	
	public ResultSet getAwayInfo(String teamName) {
		return App.connection.executeQuery("SELECT DISTINCT \"TeamGameStatistics\".\"Points\", \"TeamGameStatistics\".\"GameID\", \"TeamGameStatistics\".\"year\", \"Game\".\"Date\"\n" + 
				"FROM \"TeamGameStatistics\" \n" + 
				"INNER JOIN \"Game\"\n" + 
				"ON \"TeamGameStatistics\".\"GameID\" = \"Game\".\"GameCode\" AND \"TeamGameStatistics\".\"TeamCode\" = \"Game\".\"visitTeamCode\"\n" + 
				"INNER JOIN \"Teams\"\n" + 
				"ON \"TeamGameStatistics\".\"TeamCode\" = \"Teams\".\"TeamCode\" \n" + 
				"WHERE \"Teams\".\"Name\" = \'" + teamName + "\'" +
				"ORDER BY \"Game\".\"Date\";");
	}
	
	
	public void Points(ActionEvent event) {
		
		ResultSet result = getAllInfo(teamName.getText());
		String title = "Points Made from All Games from 2005 - 2013";
		if(choices.getSelectionModel().getSelectedItem() == "Home Games")
		{
			result = getHomeInfo(teamName.getText());
			title = "Points Made from Home Games from 2005 - 2013";
		}
		else if(choices.getSelectionModel().getSelectedItem() == "Away Games")
		{
			result = getAwayInfo(teamName.getText());
			title = "Points Made from Away Games from 2005 - 2013";
		}
		
//		CategoryAxis xAxis = new CategoryAxis();
		xAxis.setLabel("Year");
//		
//		NumberAxis yAxis = new NumberAxis();
		yAxis.setLabel("Points");
		
//		lineChart
		lineChart.setTitle(title);
		
		XYChart.Series<String, Number> data = new XYChart.Series<>();
		
		try {
			while (result.next()) {
				int points = Integer.parseInt(result.getString(1));
//				int GameID = Integer.parseInt(result.getString(2));
				String year = result.getString(3);
				String date = result.getString(4);
				data.getData().add(new XYChart.Data<String, Number>(date, points));
				
		    }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		lineChart.getData().add(data);
		lineChart.setVisible(true);
		
		
	}	
}
