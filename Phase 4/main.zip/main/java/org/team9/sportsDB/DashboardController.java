/*
 * Name: Siyuan Yang
 * Date: 03/02/2020
 * Version: (number, edited by) 
 * 	- 0.0.1 Sacheth 
 *  - 0.0.2 Siyuan
 * 
 * Notes: Manages the menu controller for the application
 * 
 */

package org.team9.sportsDB;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.util.Callback;

public class DashboardController implements Initializable  {
	
	@FXML
	private TableView<String> tableView = new TableView<String>();
	@FXML
	private ListView<String> list;
	
	@FXML
	private TableController tableController;
	
	@FXML
	private Button filterByCol;
	
	@FXML
	private ChoiceBox<String> colNamesToFilter;// = new ChoiceBox();
	
	
//	@FXML
//	private ColumnsController columnController = new ColumnsController();
	
	
	@FXML
	public void handleLoadClicked(ActionEvent event) {
		FileChooser fc = new FileChooser();
    	fc.setTitle("Load");
    	fc.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("csv file", "*.csv"));
    	File selectedFile = fc.showOpenDialog(null);
    	if (selectedFile != null) {
    		list.getItems().add(selectedFile.getAbsolutePath());
    	} else {
    		System.out.println("file is not valid");
    	}	
	}
	
	@FXML
    public void handleSaveCliked(ActionEvent event) {
		String name = TableController.selectedTable;
		String query = "SELECT column_name FROM information_schema.columns\r\n" + 
				"WHERE table_schema = 'public' \r\n" + 
				"AND table_name  = N\'" + name + "\';";
		ResultSet colNames = App.connection.executeQuery(query);
		ResultSet results = App.connection.executeQuery("SELECT * FROM \"" + name.strip() +"\" LIMIT 10;");
		try {
			  // Create file 
			  FileWriter csvWriter = new FileWriter("new.csv");
			  BufferedWriter out = new BufferedWriter(csvWriter);
			  while(colNames.next()) {
					out.write(colNames.getString("column_name") + ",");
			  }
			  out.write("\n");
			  while (results.next()) {
				  for (int i = 1; i <= results.getMetaData().getColumnCount(); i++){
		                out.write(results.getString(i) + ",");
		          }
				  out.write("\n");
		      }
			  //Close the output stream
			  out.close();
		} catch (Exception e) {//Catch exception if any
			  System.err.println("Error: " + e.getMessage());
		}
    }  
    
    @FXML
    public void CloseApp(ActionEvent event) {
		Platform.exit();
		System.exit(0);
    }
    
	

    public void updateTable(String name, String filteredCol) {
		//Make new table, also reseting the tableview
		System.out.println("Update table called");
		tableView.getItems().clear();
		tableView.getColumns().clear();

		
		String query = "SELECT column_name FROM information_schema.columns\r\n" + 
				"WHERE table_schema = 'public' \r\n" + 
				"AND table_name  = N\'" + name + "\';";
		
		ResultSet colNames = App.connection.executeQuery(query);
		ObservableList c = FXCollections.observableArrayList();
		try {
			while(colNames.next()) {
				c.add(colNames.getString("column_name"));
			}
			colNamesToFilter.setItems(c);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		ResultSet results;
		
		if(filteredCol != null)		{
			results = App.connection.executeQuery("SELECT \"" + filteredCol + "\" FROM \"" + name.strip() +"\" LIMIT 10;"); 
		}else {
			results = App.connection.executeQuery("SELECT * FROM \"" + name.strip() +"\" LIMIT 10;");
		}
		// The values in the table
		
		
		
		ObservableList data = FXCollections.observableArrayList();
		try {
		 /**********************************
         * TABLE COLUMN ADDED DYNAMICALLY *
         **********************************/
        for(int i=0 ; i<results.getMetaData().getColumnCount(); i++){
            //We are using non property style for making dynamic table
        	if(i == results.getMetaData().getColumnCount())break;
            final int j = i;                
            TableColumn col = new TableColumn(results.getMetaData().getColumnName(i+1));
            col.setCellValueFactory(new Callback<CellDataFeatures<ObservableList,String>,ObservableValue<String>>(){                    
                public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {                                                                                              
                    return new SimpleStringProperty(param.getValue().get(j).toString());                        
                }                    
            });

            tableView.getColumns().addAll(col); 
            System.out.println("Column ["+i+"] ");
        }

        /********************************
         * Data added to ObservableList *
         ********************************/
        while(results.next()){
            //Iterate Row
            ObservableList<String> row = FXCollections.observableArrayList();
            for(int i=1 ; i<=results.getMetaData().getColumnCount(); i++){
                //Iterate Column
                row.add(results.getString(i));
            }
            System.out.println("Row [1] added "+row );
            data.add(row);

        }

        //FINALLY ADDED TO TableView
        tableView.setItems(data);
      }catch(Exception e){
          e.printStackTrace();
          System.out.println("Error on Building Data");             
      }
}

	

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		tableController.setParentController(this);
		tableController.listViewTables.setOnMouseClicked(new EventHandler<MouseEvent>(){
			@Override
		    public void handle(MouseEvent arg0) {
				
				TableController.selectedTable = tableController.listViewTables.getSelectionModel().getSelectedItem();
			  	updateTable(TableController.selectedTable, null);
			     
		       
		    }
		});
		filterByCol.setOnAction(new EventHandler<ActionEvent>() {
		    @Override public void handle(ActionEvent e) {
		    	if(TableController.selectedTable != null) {
		    		if(colNamesToFilter.getSelectionModel().getSelectedItem() != null)
		    		updateTable(TableController.selectedTable, (String) colNamesToFilter.getValue());
		    	}
		    	
		    }
		});

	}
    
    
}
