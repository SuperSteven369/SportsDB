/*
 * Name: Sacheth Swaminathan
 * Date: 02/29/2020
 * Version: (number, edited by) 
 * 	- 0.0.1 Sacheth 
 * 
 * Notes: Manages the connection to the database
 * 
 */

package org.team9.dbConnection;

public final class DBConfig {
	public static final String user = "p1008217";
    public static final String pswd = "19972000vpMP";
    public static final String dbName = "jdbc:postgresql://csce-315-db.engr.tamu.edu/team900_9";
    
}
