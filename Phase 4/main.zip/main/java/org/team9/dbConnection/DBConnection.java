/*
 * Name: Sacheth Swaminathan
 * Date: 02/29/2020
 * Version: (number, edited by) 
 * 	- 0.0.1 Sacheth 
 * 
 * Notes: Manages the connection to the database through an object
 * 
 */

package org.team9.dbConnection;

import java.sql.*;


public class DBConnection {
	
	
private Connection conn;
	/**
	 * Class constructor
	 */
	public DBConnection() {
		getConnection();
	}
	/**
	 * Creates a connection to the database, and then manages it 
	 * in an object
	 */
	public void getConnection() {
		 //Building the connection
	     conn = null;
	     try {
		        Class.forName("org.postgresql.Driver");
		        conn = DriverManager.getConnection(DBConfig.dbName,
		        		DBConfig.user, DBConfig.pswd);
		     } catch (Exception e) {
		        e.printStackTrace();
		        System.err.println(e.getClass().getName()+": "+e.getMessage());
		        System.exit(0);
		     }//end try catch
	    
	}
	
	/**
	 * Closes the connection to the database via the conn object
	 */
	public void closeConnection() {
		//closing the connection
	    try {
	      conn.close();
	      System.out.println("Connection Closed.");
	    } catch(Exception e) {
	      System.out.println("Connection NOT Closed.");
	    }//end try catch
	}
	
	/**
	 * Executes a query to the database and returns a ResultSet 
	 * @param query a query in SQL in string format
	 * @return a ResultSet object which can be parsed
	 */
	public ResultSet executeQuery(String query) {
		try{
		     //create a statement object
		       Statement stmt = conn.createStatement();
		       //create an SQL statement
		       String sqlStatement = query;
		       //send statement to DBMS
		       ResultSet result = stmt.executeQuery(sqlStatement);
		       return result;
		   } catch (Exception e){
		     System.out.println("Error accessing Database.");
		     e.printStackTrace();
		   }
		return null;
	}


}
